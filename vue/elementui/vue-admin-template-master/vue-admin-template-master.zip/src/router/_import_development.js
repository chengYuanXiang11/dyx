module.exports = file => () => import('@/views/' + file)// vue-loader at least v13.0.0+
