module.exports = {

  title: 'Vue Admin Template',

  /**
   * @type {boolean} true | false
   * @description 是否固定header
   */
  fixedHeader: false,

  /**
   * @type {boolean} true | false
   * @description 是否在侧边栏中显示徽标
   */
  sidebarLogo: false
}
