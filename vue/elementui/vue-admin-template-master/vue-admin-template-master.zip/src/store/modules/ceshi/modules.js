import ceshi2 from './ceshi/index'
const modules = {
  ceshi2
}
export default modules
