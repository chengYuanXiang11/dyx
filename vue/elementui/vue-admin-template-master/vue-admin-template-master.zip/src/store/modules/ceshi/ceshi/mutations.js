import types from './types'
const mutation = {
  [types.INTHETS](state, ployad) {
    state.name = ployad
  }
}
export default mutation
