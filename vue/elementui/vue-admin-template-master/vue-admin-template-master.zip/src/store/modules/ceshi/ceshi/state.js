const state = {
  name: 'ceshi2',
  gae: '22'
}
export default state
