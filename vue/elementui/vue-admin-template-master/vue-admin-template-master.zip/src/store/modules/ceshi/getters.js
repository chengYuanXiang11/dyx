const getter = {
  ceshiname(state) {
    return state.name
  }
}
export default getter
