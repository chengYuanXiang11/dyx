const getter = {
  ceshi2name(state) {
    return state.name
  }
}
export default getter
