const INTHETS = 'INTHETS'

export default {
  INTHETS
}
