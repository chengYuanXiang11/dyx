const state = {
  name: 'ceshi',
  gae: '11'
}
export default state
